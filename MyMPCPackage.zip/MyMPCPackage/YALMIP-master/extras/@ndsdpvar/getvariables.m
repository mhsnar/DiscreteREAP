function v = getvariables(X)
% getvariables (overloaded)

v = getvariables(sdpvar(X));
